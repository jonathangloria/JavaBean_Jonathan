/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressbar;

/**
 *
 * @author Jonathan
 */
import java.awt.*;
public class ProgressBar extends Panel {
    private int java=0, php=0, sum;
    private Label label;
    private long maxValue=30;
    
    public void setMaxValue(long max) {
        maxValue = max;
    }
    public long getMaxValue() {
        return maxValue;
    }
    public ProgressBar() {
        setBackground(Color.blue);
        setForeground(Color.white);
        label = new Label("0-0");
        add(label);
    }
    public void incrementJava () {
        if (java < maxValue) {
            java++;
            label.setText(java+"-"+php);
        }
        else label.setText("!!");
    }
    public void incrementPhp () {
        if (php < maxValue) {
            php++;
            label.setText(java+"-"+php);
        }
        else label.setText("!!");
    }
    public void reset(){
        java=0;
        php=0;
        label.setText(java+"-"+php);
    }
    public int getJava(){
        return java;
    }
    public int getPhp(){
        return php;
    }
    public int getSum(){
        return sum = java+php;
    } 
}